<?php
// the following line has to be the first line of code executed in the php site
// put correct path to include this file that start caching
include_once('nitropack-sdk/nitro.start.php');
// here you can load web site code. and it has to be included in every website page
// if your website has main template or config file, you have to put this code in it
?>